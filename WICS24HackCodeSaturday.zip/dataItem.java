public abstract class dataItem {
    dataItem (String[] args) {
        // to be overwritten
        System.out.println("fd");
    }
    // ne vermind, didnt work
}
